@extends('frontend.layouts')
{{-- @section('page_title', 'Daily Shop | '.$product->name ) --}}
@section('page_title', 'Daily Shop | Category')
@section('container')



   <!-- product category -->
   <section id="aa-product-category">
     <div class="container">
       <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-8">
           <div>&nbsp;</div>
           <div>&nbsp;</div>
           <h2>Your email has been verified successfully!</h2>
           <div>&nbsp;</div>
           <div>&nbsp;</div>
         </div>

       </div>
     </div>
   </section>
   <!-- / product category -->

@endsection
