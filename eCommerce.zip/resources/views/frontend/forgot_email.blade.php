<p>Hello! <h3>{{ $name }}</h3></p>
<p>Click below for change your password</p>
<p><a href="{{ url('/forgot_password_change') }}/{{ $rand_id }}" title="Forgot Password">Click here</a></p>
