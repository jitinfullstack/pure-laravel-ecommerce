<h5>Welcome </h5><h3>{{ $name }}</h3>
<p><a href="{{ url('/verification') }}/{{ $rand_id }}" title="Email Veridication">Click here</a> to verify your email id.</p>
