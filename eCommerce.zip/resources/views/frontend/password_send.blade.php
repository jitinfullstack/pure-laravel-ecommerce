<h5>Welcome </h5><h3>{{ $name }}</h3>
<p>Your password {{ $password }}</p>
