<?php $__env->startSection('page_title', 'Manage Coupon'); ?>
<?php $__env->startSection('coupon_select', 'active'); ?>
<?php $__env->startSection('container'); ?>

<h1>Manage Coupon</h1>
<a href="<?php echo e(route('admin.coupon')); ?>">
    <button type="button" class="btn btn-success btn-block mt-2">
        Back
    </button>
</a>
<div class="row m-t-30">
    <div class="col-md-12">

        <div class="card">
            <div class="card-body">

                <form action="<?php echo e(route('coupon.manage_coupon_process')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="title" class="control-label mb-1">Coupon Title</label>
                                <input id="title" name="title" type="text" class="form-control" value="<?php echo e($title); ?>" aria-required="true" aria-invalid="false" required>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="code" class="control-label mb-1">Coupon Code</label>
                                <input id="code" name="code" type="text" class="form-control" value="<?php echo e($code); ?>" aria-required="true" aria-invalid="false" required>
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">

                            <div class="col-md-6">
                                <label for="value" class="control-label mb-1">Coupon Value</label>
                                <input id="value" name="value" type="text" class="form-control" value="<?php echo e($value); ?>" aria-required="true" aria-invalid="false" required>
                                <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="type" class="control-label mb-1">Coupon Type</label>
                                <select id="type" name="type" class="form-control" required>
                                    <?php if($type == 'percent'): ?>
                                        <option selected value="percent">Percentage</option>
                                        <option value="value">Value</option>
                                    <?php else: ?>
                                        <option value="percent">Percentage</option>
                                        <option selected value="value">Value</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">

                            <div class="col-md-6">
                                <label for="min_order_amount" class="control-label mb-1">Min Order Amount</label>
                                <input id="min_order_amount" name="min_order_amount" type="text" class="form-control" value="<?php echo e($min_order_amount); ?>" aria-required="true" aria-invalid="false" required>

                            </div>

                            <div class="col-md-6">
                                <label for="is_one_time" class="control-label mb-1">Is One Time</label>
                                <select id="is_one_time" name="is_one_time" class="form-control" required>
                                    <?php if($is_one_time == '1'): ?>
                                        <option selected value="1">Yes</option>
                                        <option value="0">No</option>
                                    <?php else: ?>
                                        <option value="1">Yes</option>
                                        <option selected value="0">No</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div>
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                            <span id="payment-button-amount">Submit</span>
                            <span id="payment-button-sending" style="display:none;">Sending…</span>
                        </button>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($id); ?>"/>
                </form>
            </div>

        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/admin/coupon/manage_coupon.blade.php ENDPATH**/ ?>