<?php $__env->startSection('page_title', 'Product Review'); ?>
<?php $__env->startSection('product_review_select', 'active'); ?>
<?php $__env->startSection('container'); ?>

<h1>Product Review</h1>

<?php if(Session::has('message')): ?>
    <div class="sufee-alert alert with-close alert-dark alert-dismissible fade show">
        <span class="badge badge-pill badge-dark">Success</span>
        <?php echo e(Session::get('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
<?php endif; ?>
<div class="row m-t-20">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Product</th>
                        <th>Rating</th>
                        <th>Review</th>
                        <th>Added On</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $product_review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($review->id); ?></td>
                            <td><?php echo e($review->name); ?></td>
                            <td><?php echo e($review->pname); ?></td>
                            <td><?php echo e($review->rating); ?></td>
                            <td><?php echo e($review->review); ?></td>
                            <td><?php echo e($review->added_on); ?></td>
                            <td>
                                <?php if($review->status == 1): ?>
                                    <a href="<?php echo e(url('admin/update_product_review/status/0')); ?>/<?php echo e($review->id); ?>" class="mr-2 btn btn-sm btn-info">Active</a>
                                <?php elseif($review->status == 0): ?>
                                    <a href="<?php echo e(url('admin/update_product_review/status/1')); ?>/<?php echo e($review->id); ?>" class="mr-2 btn btn-sm btn-danger">Deactive</a>
                                <?php endif; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/admin/product_review/all_product_review.blade.php ENDPATH**/ ?>