<?php $__env->startSection('page_title', 'Order Details'); ?>
<?php $__env->startSection('order_select', 'active'); ?>
<?php $__env->startSection('container'); ?>

<h1>Order Details - <?php echo e($order_details[0]->id); ?></h1>

<a href="<?php echo e(route('admin.order')); ?>">
    <button type="button" class="btn btn-success btn-block mt-2">
        Back
    </button>
</a>

<div class="row m-t-30 m-b-20">
    <div class="col-md-12">
        <div class="cart-view-area">
            <div class="cart-view-table">
                <div class="table-responsive m-b-40">
                    <table class="table table-borderless table-data3">
                        <thead>
                            <tr>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <strong>Update Order Status: </strong>
                                    <p>
                                        <select class="form-control" id="order_status" onchange="update_order_status(<?php echo e($order_details[0]->id); ?>)">
                                            <?php
                                              foreach ($order_status as $list) {
                                                  if($order_details[0]->order_status == $list->id){
                                                    echo '<option  value="'.$list->id.'">'.$list->order_status.'</option>';                                                  }
                                                  else{
                                                    echo '<option value="'.$list->id.'">'.$list->order_status.'</option>';
                                                  }
                                                }
                                            ?>
                                        </select>
                                    </p>
                                    <br>
                                </td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="cart-view-area">
            <div class="cart-view-table">
                <div class="table-responsive m-b-40">
                    <table class="table table-borderless table-data3">
                        <thead>
                            <tr>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <strong>Update Payment Status: </strong>
                                    <p>
                                        <select class="form-control" id="payment_status" onchange="update_payment_status(<?php echo e($order_details[0]->id); ?>)">
                                            <?php
                                              foreach ($payment_status as $list) {
                                                  if($order_details[0]->payment_status == $list){
                                                    echo '<option selected value="'.$list.'">'.$list.'</option>';
                                                  }
                                                  else{
                                                    echo '<option value="'.$list.'">'.$list.'</option>';
                                                  }
                                                }
                                            ?>
                                        </select>
                                    </p>
                                    <br>
                                </td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="cart-view-area">
            <div class="cart-view-table">
                <div class="table-responsive m-b-40">
                    <table class="table table-borderless table-data3">
                        <thead>
                            <tr>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <strong>Track Details: </strong><br>
                                    <form method="post">
                                        <textarea class="form-control" name="track_details" required><?php echo e($order_details[0]->track_details); ?></textarea>
                                        <button type="submit" class="btn btn-sm btn-success m-t-10">Submit</button>
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    <br>
                                </td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row m-b-20">
<div class="col-md-6">
    <div class="cart-view-area">

        <div class="cart-view-table">
        <form action="">

            <h3 class="m-b-10">Details Address</h3>
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Name: </strong> <p><?php echo e($order_details[0]->name); ?></p><br>
                            <strong>Phone: </strong> <p>(<?php echo e($order_details[0]->mobile); ?>)</p><br>
                            <strong>Email: </strong> <p><?php echo e($order_details[0]->email); ?></p><br>
                            <strong>Address: </strong> <p><?php echo e($order_details[0]->address); ?>, <?php echo e($order_details[0]->city); ?>, <?php echo e($order_details[0]->state); ?>, <?php echo e($order_details[0]->zipcode); ?></p>
                        </td>
                        <td></td>
                    </tr>
                </tbody>
                </table>
            </div>
        </form>
        </div>
    </div>

</div>



<div class="col-md-6">
    <div class="cart-view-area">

        <div class="cart-view-table">
        <form action="">

            <h3 class="m-b-10">Order Details</h3>
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Order Status: </strong> <p><?php echo e($order_details[0]->order_status); ?></p><br>
                                <strong>Payment Status: </strong> <p><?php echo e($order_details[0]->payment_status); ?></p><br>
                                <strong>Payment Type: </strong> <p><?php echo e($order_details[0]->payment_type); ?></p><br>
                                <?php
                                    if($order_details[0]->payment_id != ''){
                                        echo '<strong>Address: </strong> <p> '.$order_details[0]->payment_id .'</p>';
                                    }
                                ?>

                            </td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </form>
        </div>
    </div>

</div>

</div>


<div class="row">

    <div class="col-md-12">
    <div class="cart-view-area">

        <div class="cart-view-table">
        <form action="">

            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                    <th>Product</th>
                    <th>Image</th>
                    <th>Size</th>
                    <th>Color</th>
                    <th>Price</th>
                    <th>Qunatity</th>
                    <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $totalAmount = 0;
                    ?>
                    <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $totalAmount = $totalAmount + ($order_detail->price * $order_detail->quantity);
                    ?>
                    <tr>
                        <td><?php echo e($order_detail->pname); ?></td>
                        <td><img src="<?php echo e(asset('storage/media/'.$order_detail->attr_image)); ?>" alt="<?php echo e($order_detail->name); ?>" width="60px"></td>
                        <td><?php echo e($order_detail->size); ?></td>
                        <td><?php echo e($order_detail->color); ?></td>
                        <td>Rs. <?php echo e($order_detail->price); ?></td>
                        <td><?php echo e($order_detail->quantity); ?></td>
                        <td>Rs. <?php echo e($order_detail->price * $order_detail->quantity); ?></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td colspan="5">&nbsp;</td>
                        <td><strong>Total </strong></td>
                        <td><strong>Rs. <?php echo e($totalAmount); ?></strong></td>
                    </tr>


                    <?php
                    if($order_details[0]->coupon_value>0){

                        echo '<tr>
                                <td colspan="5">&nbsp;</td>
                                <td><strong>Coupon <span class="coupon_apply_txt">('.$order_details[0]->coupon_code.')</span></strong></td>
                                <td><strong>Rs. '.$order_details[0]->coupon_value. '</strong></td>
                            </tr>';

                        $totalAmount = $totalAmount - $order_details[0]->coupon_value;

                        echo '<tr>
                                <td colspan="5">&nbsp;</td>
                                <td><strong>Final Total </strong></td>
                                <td><strong>Rs. '.$totalAmount. '</strong></td>
                            </tr>';
                    }
                    ?>

                    </tbody>
                </table>
            </div>

        </form>

        </div>
    </div>
    </div>
</div>

<div class="row">&nbsp;</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/admin/order/order_details.blade.php ENDPATH**/ ?>