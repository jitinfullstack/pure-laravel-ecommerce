<?php $__env->startSection('page_title', 'Daily Shop | Success'); ?>
<?php $__env->startSection('container'); ?>



   <!-- product category -->
   <section id="aa-product-category">
     <div class="container">
       <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-8">
           <div>&nbsp;</div>
           <div>&nbsp;</div>
           <h2>Your order has been placed successfully!</h2>
           <h3>Order Id: <strong style="color: #f66666"><?php echo e(session()->get('ORDER_ID')); ?></strong></h3>
           <div>&nbsp;</div>
           <div>&nbsp;</div>
         </div>

       </div>
     </div>
   </section>
   <!-- / product category -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/frontend/order_placed.blade.php ENDPATH**/ ?>