<?php $__env->startSection('page_title', 'Product'); ?>
<?php $__env->startSection('product_select', 'active'); ?>
<?php $__env->startSection('container'); ?>

<h1>Product</h1>
<a href="<?php echo e(route('admin.manage_product')); ?>">
    <button type="button" class="btn btn-success mt-2 mb-3">
        Add Product
    </button>
</a>
<?php if(Session::has('message')): ?>
    <div class="sufee-alert alert with-close alert-dark alert-dismissible fade show">
        <span class="badge badge-pill badge-dark">Success</span>
        <?php echo e(Session::get('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
<?php endif; ?>
<div class="row m-t-20">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>prodoct name</th>
                        <th>product slug</th>
                        <th>product image</th>
                        <th>created at</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->slug); ?></td>
                            <td>
                                <?php if($product->image!=''): ?>
                                    <img src="<?php echo e(asset('storage/media')); ?>/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" width="100px">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($product->created_at); ?></td>
                            <td>
                                <?php if($product->status == 1): ?>
                                    <a href="<?php echo e(url('admin/product/status/0')); ?>/<?php echo e($product->id); ?>" class="mr-2 btn btn-sm btn-info">Active</a>
                                <?php elseif($product->status == 0): ?>
                                    <a href="<?php echo e(url('admin/product/status/1')); ?>/<?php echo e($product->id); ?>" class="mr-2 btn btn-sm btn-danger">Deactive</a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.edit_manage_product', ['product_id' => $product->id])); ?>" class="mr-2"><i class="fa fa-edit fa-2x text-info"></i></a>
                                <a href="<?php echo e(route('product.delete_product', ['product_id'=> $product->id ])); ?>" class="mr-2"><i class="fa fa-times fa-2x text-danger"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/admin/product/all_product.blade.php ENDPATH**/ ?>