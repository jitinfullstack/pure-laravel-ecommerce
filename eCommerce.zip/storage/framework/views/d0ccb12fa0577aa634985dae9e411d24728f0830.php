<?php $__env->startSection('page_title', 'Coupons'); ?>
<?php $__env->startSection('coupon_select', 'active'); ?>
<?php $__env->startSection('container'); ?>

<h1>Coupons</h1>
<a href="<?php echo e(route('admin.manage_coupon')); ?>">
    <button type="button" class="btn btn-success mt-2 mb-3">
        Add Coupon
    </button>
</a>
<?php if(Session::has('message')): ?>
    <div class="sufee-alert alert with-close alert-dark alert-dismissible fade show">
        <span class="badge badge-pill badge-dark">Success</span>
        <?php echo e(Session::get('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
<?php endif; ?>
<div class="row m-t-20">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>title</th>
                        <th>code</th>
                        <th>value</th>
                        <th>created at</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($coupon->id); ?></td>
                            <td><?php echo e($coupon->title); ?></td>
                            <td><?php echo e($coupon->code); ?></td>
                            <td><?php echo e($coupon->value); ?></td>
                            <td><?php echo e($coupon->created_at); ?></td>
                            <td>
                                <?php if($coupon->status == 1): ?>
                                    <a href="<?php echo e(url('admin/coupon/status/0')); ?>/<?php echo e($coupon->id); ?>" class="mr-2 btn btn-sm btn-info">Active</a>
                                <?php elseif($coupon->status == 0): ?>
                                    <a href="<?php echo e(url('admin/coupon/status/1')); ?>/<?php echo e($coupon->id); ?>" class="mr-2 btn btn-sm btn-danger">Deactive</a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.edit_manage_coupon', ['coupon_id' => $coupon->id])); ?>"><i class="fa fa-edit fa-2x text-info"></i></a>
                                <a href="<?php echo e(route('coupon.delete_coupon', ['coupon_id'=> $coupon->id ])); ?>" style="margin-left: 10px"><i class="fa fa-times fa-2x text-danger"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/admin/coupon/all_coupon.blade.php ENDPATH**/ ?>