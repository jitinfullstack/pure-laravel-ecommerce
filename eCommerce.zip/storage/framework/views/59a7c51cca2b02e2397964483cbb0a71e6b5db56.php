<p>Hello! <h3><?php echo e($name); ?></h3></p>
<p>Click below for change your password</p>
<p><a href="<?php echo e(url('/forgot_password_change')); ?>/<?php echo e($rand_id); ?>" title="Forgot Password">Click here</a></p>
<?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/frontend/forgot_email.blade.php ENDPATH**/ ?>