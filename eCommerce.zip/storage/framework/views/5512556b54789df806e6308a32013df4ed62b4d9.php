<?php $__env->startSection('page_title', 'Customers'); ?>
<?php $__env->startSection('customer_select', 'active'); ?>
<?php $__env->startSection('container'); ?>

<h1>Customers</h1>

<?php if(Session::has('message')): ?>
    <div class="sufee-alert alert with-close alert-dark alert-dismissible fade show">
        <span class="badge badge-pill badge-dark">Success</span>
        <?php echo e(Session::get('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
<?php endif; ?>
<div class="row m-t-20">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>name</th>
                        <th>email</th>
                        <th>mobile</th>
                        
                        <th>created at</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($customer->id); ?></td>
                            <td><?php echo e($customer->name); ?></td>
                            <td><?php echo e($customer->email); ?></td>
                            <td><?php echo e($customer->mobile); ?></td>
                            
                            <td><?php echo e($customer->created_at); ?></td>
                            <td>
                                <?php if($customer->status == 1): ?>
                                    <a href="<?php echo e(url('admin/customer/status/0')); ?>/<?php echo e($customer->id); ?>" class="mr-2 btn btn-sm btn-info">Active</a>
                                <?php elseif($customer->status == 0): ?>
                                    <a href="<?php echo e(url('admin/customer/status/1')); ?>/<?php echo e($customer->id); ?>" class="mr-2 btn btn-sm btn-danger">Deactive</a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.show_customer', ['customer_id' => $customer->id])); ?>"><i class="fa fa-edit fa-2x text-info"></i></a>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/admin/customer/all_customer.blade.php ENDPATH**/ ?>