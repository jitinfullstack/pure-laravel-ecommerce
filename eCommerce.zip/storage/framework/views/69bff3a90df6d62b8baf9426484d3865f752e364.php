<?php $__env->startSection('page_title', 'Category'); ?>
<?php $__env->startSection('category_select', 'active'); ?>
<?php $__env->startSection('container'); ?>

<h1>Category</h1>
<a href="<?php echo e(route('admin.manage_category')); ?>">
    <button type="button" class="btn btn-success mt-2 mb-3">
        Add Category
    </button>
</a>
<?php if(Session::has('message')): ?>
    <div class="sufee-alert alert with-close alert-dark alert-dismissible fade show">
        <span class="badge badge-pill badge-dark">Success</span>
        <?php echo e(Session::get('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
<?php endif; ?>
<div class="row m-t-20">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>category name</th>
                        <th>category slug</th>
                        <th>created at</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->category_name); ?></td>
                            <td><?php echo e($category->category_slug); ?></td>
                            <td><?php echo e($category->created_at); ?></td>
                            <td>
                                <?php if($category->status == 1): ?>
                                    <a href="<?php echo e(url('admin/category/status/0')); ?>/<?php echo e($category->id); ?>" class="mr-2 btn btn-sm btn-info">Active</a>
                                <?php elseif($category->status == 0): ?>
                                    <a href="<?php echo e(url('admin/category/status/1')); ?>/<?php echo e($category->id); ?>" class="mr-2 btn btn-sm btn-danger">Deactive</a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.edit_manage_category', ['category_id' => $category->id])); ?>" class="mr-2"><i class="fa fa-edit fa-2x text-info"></i></a>
                                <a href="<?php echo e(route('category.delete_category', ['category_id'=> $category->id ])); ?>" class="mr-2"><i class="fa fa-times fa-2x text-danger"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/admin/category/all_category.blade.php ENDPATH**/ ?>