<?php $__env->startSection('page_title', 'Order'); ?>
<?php $__env->startSection('order_select', 'active'); ?>
<?php $__env->startSection('container'); ?>

<h1>Order</h1>

<div class="row m-t-20">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer Details</th>
                        <th>Amount</th>
                        <th>Order Status</th>
                        <th>Payment Status</th>
                        <th>Payment Type</th>
                        <th>Placed On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="order_id_btn"><a href="<?php echo e(route('admin.order_details', ['id' => $order->id])); ?>"><?php echo e($order->id); ?></a></td>
                            <td>
                                <?php echo e($order->name); ?><br>
                                <?php echo e($order->email); ?><br>
                                <?php echo e($order->mobile); ?><br>
                                <?php echo e($order->address); ?>, <?php echo e($order->city); ?>, <?php echo e($order->state); ?>, <?php echo e($order->zipcode); ?>

                            </td>
                            <td><?php echo e($order->total_amount); ?></td>
                            <td><?php echo e($order->order_status); ?></td>
                            <td><?php echo e($order->payment_status); ?></td>
                            <td><?php echo e($order->payment_type); ?></td>
                            <td><?php echo e($order->added_on); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/admin/order/all_order.blade.php ENDPATH**/ ?>