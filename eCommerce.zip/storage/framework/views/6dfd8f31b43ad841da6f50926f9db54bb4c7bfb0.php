<?php $__env->startSection('page_title', 'Daily Shop | Order'); ?>
<?php $__env->startSection('container'); ?>

<!-- catg header banner section -->
<section id="aa-catg-head-banner">
    <img src="<?php echo e(asset('frontend_assets/img/fashion/fashion-header-bg-8.jpg')); ?>" alt="fashion img">
    <div class="aa-catg-head-banner-area">
      <div class="container">
       <div class="aa-catg-head-banner-content">
         <h2>Order Page</h2>
         <ol class="breadcrumb">
           <li><a href="index.html">Home</a></li>
           <li class="active">Order</li>
         </ol>
       </div>
      </div>
    </div>
   </section>
   <!-- / catg header banner section -->

  <!-- Cart view section -->
  <section id="cart-view">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="cart-view-area">
            <div class="cart-view-table">
              <form action="">

                <div class="table-responsive">
                   <table class="table">
                     <thead>
                       <tr>
                         <th>Order Id</th>
                         <th>Order Status</th>
                         <th>Payment Status</th>
                         <th>Payment Type</th>
                         <th>Payment Id</th>
                         <th>Total Amount</th>
                         <th>Order Placed On</th>
                       </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="order_id_btn"><a href="<?php echo e(route('order_details', ['id' => $order->id])); ?>"><?php echo e($order->id); ?></a></td>
                            <td><?php echo e($order->order_status); ?></td>
                            <td><?php echo e($order->payment_status); ?></td>
                            <td><?php echo e($order->payment_type); ?></td>
                            <td><?php echo e($order->payment_id); ?></td>
                            <td><?php echo e($order->total_amount); ?></td>
                            <td><?php echo e($order->added_on); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       </tbody>
                   </table>
                 </div>

              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- / Cart view section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel Angular eCommerce Pure\Coding\eCommerce\resources\views/frontend/order.blade.php ENDPATH**/ ?>